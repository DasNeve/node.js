const meuModulo = require('./meuModulo');

meuModulo.minhaFuncao(); // imprime "Olá do meu módulo!" no console