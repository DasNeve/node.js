exports.myDateTime = function () {
  return Date();
};